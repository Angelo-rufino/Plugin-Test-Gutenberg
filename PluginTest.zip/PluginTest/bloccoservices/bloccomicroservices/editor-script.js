var el = wp.element.createElement; //,
   // registerBlockType = wp.blocks.registerBlockType;

wp.blocks.registerBlockType('microservices/bloccomicroservices',{
	title: 'AR Services',
	icon: 'welcome-learn-more',
	category: 'common',
	


    edit: function(props) {
        return el( 'p',{ className: props.className },'ciao mondo');
    },

    save: function(props) {
        return el( 'p',{ className: props.className },'ciao mondo');
    },
} );