<?php
/*
*Plugin Name: Hello Gutenberg
*Plugin URI: https://github.com/Angelo-rufino/Plugin-Test-Gutenberg.git
*Description: Angelo Rufino testing block Gutenberg
*Author: Angelo Rufino
* Version: 1.0.0
*/

	function Microservicesfunction(){
		wp_register_script(
		'bloccoservices-editor', // nome dello script
		plugins_url('/bloccoservices/bloccomicroservices/editor-script.js', __FILE__), //URL SCRIPT
		array('wp-i18n', 'wp-editor', 'wp-components','wp-blocks', 'wp-element') //dipendenze necessarie per gutenberg
		);
		
		wp_register_style(
		'bloccoservices', //nome dello style
		plugins_url('/bloccoservices/bloccomicroservices/style.css', __FILE__), //URL CSS
		array('wp-edit-blocks') //dipendenze
		);
		
		wp_register_style(
		'bloccoservices-editor', //nome dello style
		plugins_url('/bloccoservices/bloccomicroservices/editor-style.css', __FILE__), //URL CSS
		array('wp-edit-blocks') //dipendenze
		);
		register_block_type(
		//nome del plugin/nome blocco
		'microservices/bloccomicroservices', array(
		'editor_script' => 'bloccoservices-editor',
		'editor_style' => 'bloccoservices-editor',
		'style' => 'bloccoservices'
		));
	}
		add_action('init', 'Microservicesfunction');
 	


?>